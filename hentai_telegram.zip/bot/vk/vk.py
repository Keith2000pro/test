from bot.moduls.settings import *
from time import  sleep
@dp.message_handler(commands="may")
async def may(msg:types.Message):
   try:
        i=6
        if not msg.reply_to_message:
            await msg.answer("должно быть ответом")
        else:
            for k in range(i, 0, -1):
                i=i-1
                sleep(1)
                await bot.edit_message_text(chat_id=msg.chat.id, message_id=msg.reply_to_message.message_id, text="осталось %d секунд" % i)
                if i ==0:
                    await bot.delete_message(message_id=msg.reply_to_message.message_id, chat_id=msg.chat.id)
                    p=open("bot/hentai_photos/pictures/hentai33.jpg", "rb")
                    await msg.answer_photo(p)
   except MessageCantBeDeleted:
       pass
       
                