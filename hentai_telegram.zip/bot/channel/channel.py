from bot.moduls.settings import *
from bot.states.classFSM import *
@dp.message_handler(commands="public")
async def public(msg:types.Message, state: FSMContext):
    await bot.send_message(msg.from_user.id, "какое фото загрузить в канал?")
    await public_in_channel.photo.set()
    
@dp.message_handler(content_types="photo", state=public_in_channel.photo, text="hentai")
async def public_now(msg:types.Message, state: FSMContext):
    if msg.from_user.id != 1338168183:
        return 
    else:
        channel_photos=select(table="wall", id=msg.from_user.id)
        for el in channel_photos:
            print(el[0])
        conn=sql.connect('bot/db/usersBot.db')
        cursor=conn.cursor()
        cursor.execute("INSERT INTO wall VALUES(?,?)",(None, msg.photo[0].file_id))
        conn.commit()
        await msg.answer("фото загружено")
        await bot.send_photo(CHANNEL_ID, msg.photo[0].file_id)
        await state.finish()