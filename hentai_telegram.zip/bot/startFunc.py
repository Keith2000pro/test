from bot.moduls.settings import *
import  sqlite3 as sql
from aiogram.utils.exceptions import NoStickerInRequest
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#s.connect(("8.8.8.8", 80))
#s.getsockname()[0]

@dp.message_handler(commands="start")
async def je(msg: types.Message):
    conn=sql.connect('bot/db/usersBot.db')
    cursor=conn.cursor()
    userdb=msg.from_user
    data=await user(msg)
    if data is None:
    	cursor.execute('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?)',(None, userdb.id,'@'+str(userdb.username),"NO",userdb.full_name))
    	cursor.execute('INSERT OR IGNORE INTO report VALUES(?,?)',(userdb.id, 0))
    	cursor.execute('INSERT OR IGNORE INTO rec VALUES(?,?)',(userdb.id, None))
    	cursor.execute('INSERT OR IGNORE INTO   media VALUES(?,?,?)',(None, userdb.id, None))
    	cursor.execute('INSERT OR IGNORE INTO   language VALUES(?,?,?)',(userdb.id, None, None))
    	cursor.execute('INSERT OR IGNORE INTO pay VALUES(?,?,?)',(userdb.id, "нету",0))
    	cursor.execute('INSERT OR IGNORE INTO language VALUES(?,?,?)',(userdb.id, 0,0))
    	conn.commit()
    	await msg.reply('пользователь зарегистрирован')
    else:
    	await msg.reply(data[4])
    	
@dp.message_handler(commands="profile")
async def profile(msg:types.Message):
    data=await user(msg)
    if data is None:
        await msg.answer("зарегайся /start")
    else:
        balance_info=await pay(msg)
        user_info=await user(msg)
        warning=await report(msg)
        await msg.reply(f"баланс: {balance_info[2]}\nпревелегия: {balance_info[1]}\nпредупреждений: {warning[1]}")


		