from bot.moduls.settings import *
from bot.states.classFSM import _set_photo

@dp.message_handler(commands="new_photo_chat", is_admin=True)
async def set_photo(msg: types.Message, state: FSMContext):
        await msg.answer("отправь новое фото")
        await _set_photo.photo.set()
    
@dp.message_handler(state=_set_photo.photo, content_types="document", is_admin=True)
async def l(msg:types.Message, state: FSMContext):
            photo_id=msg.document.file_id
            download=(await bot.download_file_by_id(photo_id))
            await bot.set_chat_photo(CHAT_ID, download)
            await msg.answer("ok")
            await state.finish()
            
            