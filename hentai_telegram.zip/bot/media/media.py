from bot.moduls.settings import *

@dp.message_handler(content_types="document")
async def hhh(msg:types.Message):
  try:
        photo=select(table="media", id=msg.from_user.id)   
        lang=select(table="language", id=msg.from_user.id)  
        user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
        user_channel_status_en = await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
        if user_channel_status_ru["status"] != "left" or user_channel_status_en["status"] != "left" :
             if len(photo) == 5:
                     if lang[1]==1:
                         y='ты достиг максимума фото\nдля удаления < /remove_photo >'
                         await msg.reply(translator.translate('y', src='ru', dest='en'))
                     else:
                                        y='ты достиг максимума фото\nдля удаления < /remove_photo >'
                                        await msg.reply(y)
                                        
             else:
                 data=select(table="users", id=msg.from_user.id)   
                 if data is None:
                     conn=sql.connect('bot/db/usersBot.db')
                     cursor=conn.cursor()
                     userdb=msg.from_user
                     cursor.execute('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?)',(None, userdb.id,'@'+str(userdb.username),"NO",userdb.full_name))
                     cursor.execute('INSERT OR IGNORE INTO report VALUES(?,?)',(userdb.id, 0))
                     cursor.execute('INSERT OR IGNORE INTO rec VALUES(?,?)',(userdb.id, None))
                     cursor.execute('INSERT OR IGNORE INTO pay VALUES(?,?,?)',(userdb.id, "нету",0))
                     cursor.execute('INSERT OR IGNORE INTO language VALUES(?,?,?)',(userdb.id, 0,0))
                     conn.commit()
                     orig=f'пользователь зарегистрирован\n\n⚠️если отписаться от канала\nвсе данные и платежи удаляться сразу же\nнажмите еще раз /start для выбора языка⚠️'
                     transl=translator.translate(orig, src="ru", dest="en").text
                 else:
                     conn=sql.connect('bot/db/usersBot.db')
                     cursor=conn.cursor()
                     user = msg.from_user
                     cursor.execute("INSERT  INTO media VALUES(?,?,?)",(None, user.id, msg.document.file_id,))
                     conn.commit()
                     if lang[1]==1:
                         await msg.reply(str(translator.translate("сохранено", src="ru", dest="en").text))
                     else:
                         await msg.reply("сохранено")
                 
                 
        else:
            lang=select(table="language", id=msg.from_user.id)  
            await msg.delete()
            if lang[1] ==1:
                await msg.answer(subsc,parse_mode="HTML")          
            else:
                await msg.answer(subscRu, parse_mode="HTML")
                delete(table="users", ui=id)
                delete(table="rec", ui=id)
                delete(table="report", ui=id)
                delete(table="media", ui=id)
                delete(table="pay", ui=id)
                delete(table="language", ui=id)
  except BadRequest:
        print("fuck you") 
  except TypeError:
      await msg.delete()
      await msg.answer(f"{subsc}\n{subscRu}", parse_mode="HTML")      
      
@dp.message_handler(commands="out")
async def out(msg:types.Message, state: FSMContext):
   medias=select(table="media", id=msg.from_user.id)   
   user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
   user_channel_status_en = await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
   if user_channel_status_ru["status"] != "left" or user_channel_status_en["status"] != "left":
            for el in medias:
                print(len(el))
                d=(await bot.download_file_by_id(el[0]))
                await msg.reply_photo(d)
   else:
            await msg.delete()
            conn=sql.connect("bot/db/usersBot.db")
            cursor=conn.cursor()
            id=msg.from_user.id
            delete(table="users", ui=id)
            delete(table="rec", ui=id)
            delete(table="report", ui=id)
            delete(table="media", ui=id)
            delete(table="pay", ui=id)
            delete(table="language", ui=id)
            conn.commit()
            await msg.answer(f"{subsc}\n{subscRu}",parse_mode="HTML")                  
            
@dp.message_handler(commands="remove_photo")
async def remove_photo(msg:types.Message, state: FSMContext):
                         try:
                             user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
                             user_channel_status_en=await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
                             lang=select(table="language", id=msg.from_user.id)  
                             if user_channel_status_ru["status"] != "left" or user_channel_status_en["status"] != "left":
                                 conn=sql.connect('bot/db/usersBot.db')
                                 cursor=conn.cursor()
                                 user = msg.from_user
                                 cursor.execute("DELETE FROM media WHERE user_id=?",(user.id,))
                                 conn.commit()
                                 if lang[1]==1:
                                     await msg.answer(f"{translator.translate('удалено', src='ru', dest='en').text}")
                                 else:
                                     await msg.answer("удалено")  
                             else:
                                 await msg.delete()
                                 delete(table="users", ui=id)
                                 delete(table="rec", ui=id)
                                 delete(table="report", ui=id)
                                 delete(table="media", ui=id)
                                 delete(table="pay", ui=id)
                                 delete(table="language", ui=id)
                                 if lang[1]==1:
                                     await msg.answer(subsc, parse_mode="HTML")
                                 else:
                                     await msg.answer(subscRu,parse_mode="HTML")                  
                         
                         except BadRequest:
                             print("сука")
        
@dp.message_handler(commands="g")
async def clear(msg:types.Message):
            lang=select(table="language", id=msg.from_user.id)
            delete(table="users", ui=id)
            delete(table="rec", ui=id)
            delete(table="report", ui=id)
            delete(table="media", ui=id)
            delete(table="pay", ui=id)
            delete(table="language", ui=id)
            await msg.answer("бд очищена")

@dp.message_handler(commands="photo")    
async def p(msg:types.Message):
        lang=select(table="language", id=msg.from_user.id)
        user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
        user_channel_status_en = await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
        lang=select(table="language", id=msg.from_user.id)
        if user_channel_status_ru["status"] != "left" or user_channel_status_en["status"] != "left":
            photos=select(table="media", id=msg.from_user.id)
            for pho in photos:
                d=(await bot.download_file_by_id(pho[0]))
                await msg.answer_photo(d)      
        else:
                                 await msg.delete()
                                 id=msg.from_user.id
                                 delete(table="users", ui=id)
                                 delete(table="rec", ui=id)
                                 delete(table="report", ui=id)
                                 delete(table="media", ui=id)
                                 delete(table="pay", ui=id)
                                 delete(table="language", ui=id)
                                 
                                 if lang[1]==1:
                                     await msg.answer(subsc,parse_mode="HTML")                  
                                 else:
                                     await msg.answer(subscRu, parse_mode="HTML")
