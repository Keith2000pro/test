from aiogram.types import  ContentType
from bot.moduls.settings import *
from bot.states.classFSM import add_balance

yootoken="381764678:TEST:39059"
@dp.message_handler(commands='sell')
async def privacy(msg: types.Message, state: FSMContext):
    await msg.answer("сколько вам нужно средств?")
    await add_balance.balance.set()
    
    
    
@dp.message_handler(state=add_balance.balance)
async def pay_ok(msg: types.Message, state: FSMContext):
	async with state.proxy() as balance_add:
	    user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
	    data=select(table="users", id=msg.from_user.id)
	    lang=select(table="language", id=msg.from_user.id)
	    if user_channel_status_ru["status"] != "left":
	            if data is None:
	                i=translator.translate("нажми /start", src="ru", dest="en").text
	                await msg.answer(f"{i}\nнажми /start")
	            else:
	                await bot.send_invoice(chat_id=msg.from_user.id, title="boss", description="boss", payload="Boss",provider_token=yootoken, currency="RUB", start_parameter="tygd", prices=[{"label":"Rub", "amount":10000}])
	        
	    else:
	        conn=sql.connect("bot/db/usersBot.db")
	        cursor=conn.cursor()
	        id=msg.from_user.id
	        delete(table="users", ui=id)
	        delete(table="language", ui=id)
	        delete(table="pay", ui=id)
	        delete(table="media", ui=id)
	        delete(table="rec", ui=id)
	        delete(table="report", ui=id)
	    
	    
	
	    
        

@dp.pre_checkout_query_handler()
async def pea(pre_checkout_query: types.PreCheckoutQuery):
	await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def proc_ok(msg:types.Message):
	try:
		privacy=select(table='pay', id=msg.from_user.id)
		lang=select(table="language", id=msg.from_user.id)
		if msg.successful_payment.invoice_payload=="Boss":
			conn=sql.connect('bot/db/usersBot.db')
			cursor=conn.cursor()
			cursor.execute('UPDATE pay SET privacy=?, balance=? WHERE user_id=?',('Boss👑',privacy[2]+100, msg.from_user.id))
			if lang[1] == 1:
			    await msg.reply(f"{translator.translate('ты купил звание Boss👑', src='ru', dest='en').text}", parse_mode="HTML")
			else:
			    await msg.reply("ты купил звание Boss👑")
			conn.commit()						
	except TypeError:
		await msg.delete()
		await msg.answer(f'{msg.from_user.full_name} /start')	
		