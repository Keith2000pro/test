from bot.moduls.settings import *
from aiogram.types import ParseMode
from bot.states.classFSM import *
import aiogram.utils.markdown as md
from  bot.states.classFSM import photo, stick_in_vk
import time
@dp.message_handler(commands="in_vk")
async def url(msg:types.Message, state: FSMContext):
    await msg.answer('введите ссылки')
    await photo.url.set()
    
    
@dp.message_handler(state=photo.url)
async def get_photo_vk(msg:types.Message, state: FSMContext):
    async with state.proxy() as data:
        data["url"]=msg.text
        u=data["url"]
        print(u)
            
num=randint(0, 99999999999999)            


            
@dp.message_handler(commands="form")
async def form(msg:types.Message, state: FSMContext):
            await msg.answer('введите id друга из vk')
            await stick_in_vk.id.set()
                
@dp.message_handler(state=stick_in_vk.id)
async def id(msg:types.Message, state: FSMContext):
            async with state.proxy() as data:
                data["vk_id"]=msg.text
                
                await msg.answer("введите id стикера")
                await stick_in_vk.next()
                
@dp.message_handler(state=stick_in_vk.sticker)
async def stickers(msg:types.Message, state:FSMContext):
    async with state.proxy() as data:
                        data["sticker"]=msg.text
                        user_id=md.text(data["vk_id"])
                        стикер=md.text(data["sticker"])
                        
                        vk.messages.sendSticker(user_id=kirill, sticker_id=стикер, random_id=0 )
                        await msg.answer(f'отправлено')
                        
    await state.finish()
                        
@dp.message_handler(commands="hentai")
async def l(msg:types.Message, state: FSMContext):
    await msg.answer("введите свой vk id")
    await hentai_pic.recipient.set()
    
@dp.message_handler(state=hentai_pic.recipient)
async def recipients(msg:types.Message, state: FSMContext):
            async with state.proxy() as data:
                data["id"]=msg.text
                recipients1=data["id"]
                
                vk.messages.send(user_id=recipients1, random_id=0, peer_id=recipients1, attachment=choice(hentais))
                await msg.answer(md.text(md.bold(recipients1)), parse_mode=ParseMode.MARKDOWN)
            await state.finish()
            
            
@dp.message_handler(commands="status")
async def onest(msg:types.Message, state: FSMContext):
    await msg.reply("напиши желаемый статус")
    await status.user_status.set()

@dp.message_handler(state=status.user_status)
async def new_status(msg:types.Message, state: FSMContext):
    async with state.proxy() as stat:
        stat["text"]=msg.photo[0]
        vk.status.set(text=stat["text"])
    await state.finish()

@dp.message_handler(commands='id')
async def checkk(msg:types.Message, state: FSMContext):
                                                await msg.answer("send message")
                                                await get_forward_user.user.set()
                                                
@dp.message_handler(state=get_forward_user.user)             
async def f(msg:types.Message, state: FSMContext):
            async with state.proxy() as message:
                try:
                    if msg.from_user.id==1338168183:
                        message["ui"]=msg.forward_from.id
                        message["un"]=msg.forward_from.username
                        message["ufn"]=msg.forward_from.full_name
                        await msg.answer(f" <b>user_id</b>: {message['ui']}\n<b>username</b>: @{message['un']}\n<b>full_name</b>: {message['ufn']}", parse_mode="HTML")
                        await msg.reply(msg.chat.id)
                       
                               
                except:
                               if msg.from_user.id==1338168183:
                                        message["g"]=msg.forward_from_chat.id
                                        await bot.send_message(msg.chat.id, str(f"chat_id: {message['g']}"))        
                                        
                                        
                                        
@dp.message_handler(commands="testnew")
async def tn(msg:types.Message, state: FSMContext):
    await msg.answer("отправь фото")
    await VkPhotos.photo.set()                   
    
@dp.message_handler(state=VkPhotos.photo, content_types="document")
async def j(msg:types.Message, state: FSMContext):
    async with state.proxy() as vk_photo:
        vk_photo["photo"]=msg.document.file_id                
        vk_p=vk_photo["photo"]
                     
        download=(await bot.download_file_by_id(vk_p))
        
    await state.finish()        