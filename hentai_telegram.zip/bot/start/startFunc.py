from bot.moduls.settings import *
import  sqlite3 as sql
from aiogram.utils.exceptions import NoStickerInRequest
from bot.states.classFSM import *
#s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#s.connect(("8.8.8.8", 80))
#s.getsockname()[0]

@dp.message_handler(commands="start")
async def je(msg: types.Message, state: FSMContext):
    	user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
    	user_channel_status_en = await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
    	data=select(table="users", id=msg.from_user.id)
    	if user_channel_status_en["status"] != "left" or user_channel_status_ru["status"] !="left":
    	            if data is None:
    	                conn=sql.connect('bot/db/usersBot.db')
    	                cursor=conn.cursor()
    	                userdb=msg.from_user
    	                cursor.execute('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?)',(None, userdb.id,'@'+str(userdb.username),"NO",userdb.full_name))
    	                cursor.execute('INSERT OR IGNORE INTO report VALUES(?,?)',(userdb.id, 0))
    	                cursor.execute('INSERT OR IGNORE INTO rec VALUES(?,?)',(userdb.id, None))
    	                cursor.execute('INSERT OR IGNORE INTO   language VALUES(?,?,?)',(userdb.id, None, None))
    	                cursor.execute('INSERT OR IGNORE INTO pay VALUES(?,?,?)',(userdb.id, "нету",0))
    	                cursor.execute('INSERT OR IGNORE INTO language VALUES(?,?,?)',(userdb.id, 0,0))
    	                conn.commit()
    	                orig=f'пользователь зарегистрирован\n\n⚠️если отписаться от канала\nвсе данные и платежи удаляться сразу же\nнажмите еще раз /start для выбора языка⚠️'
    	                transl=translator.translate(orig, src="ru", dest="en").text
    	                await msg.reply(f"{transl}\n{orig}", parse_mode="HTML")
    	            else:
    	                if msg.chat.id == msg.from_user.id:
    	                    chooiseLang=translator.translate("выберите язык", src="ru", dest="en").text
    	                    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    	                    buttons = ["EN", "RU"]
    	                    keyboard.add(*buttons)
    	                    await msg.answer(f"{chooiseLang}\nвыберите язык", reply_markup=keyboard)
    	                    await Lang.lang.set()
    	                else:
    	                    await msg.reply("нужно писать в лс")
    	                
    	else:
    	        
    	        await msg.answer(f"{subsc}\n{subscRu}",parse_mode="HTML")       
    	        conn=sql.connect("bot/db/usersBot.db")
    	        cursor=conn.cursor()
    	        user=msg.from_user.id
    	        cursor.execute("DELETE FROM users WHERE user_id=?",(user,))
    	        cursor.execute("DELETE FROM rec WHERE user_id=?",(user,))
    	        cursor.execute("DELETE FROM report WHERE user_id=?",(user,))
    	        cursor.execute("DELETE FROM media WHERE user_id=?",(user,))
    	        cursor.execute("DELETE FROM pay WHERE user_id=?",(user,))
    	        cursor.execute("DELETE FROM language WHERE user_id=?",(user,))
    	        conn.commit()
    	        
    	        
@dp.message_handler(state=Lang.lang)
async def chooise_lang(msg:types.Message, state: FSMContext):
    	       async with state.proxy() as languag:
    	           languag["lang"]=msg.text
    	           lang=select(table="language", id=msg.from_user.id)
    	           languae=languag["lang"]
    	           conn=sql.connect('bot/db/usersBot.db')
    	           cursor=conn.cursor()
    	           userdb=msg.from_user
    	           if languae =="RU":
    	               cursor.execute("UPDATE language SET RU=?, EN=? WHERE user_id=?",(1,0, userdb.id))
    	               await msg.reply("выбран русский", reply_markup=types.ReplyKeyboardRemove())
    	               await state.finish()
    	           elif languae=="EN":
    	               h=translator.translate("выбран английский", src="ru", dest="en").text
    	               
    	               await msg.answer(h, reply_markup=types.ReplyKeyboardRemove())
    	               cursor.execute("UPDATE language SET RU=?, EN=? WHERE user_id=?",(0,1, userdb.id))
    	               conn.commit()
    	               await state.finish()
    	           else:
    	                  await msg.answer("нету других языков", reply_markup=types.ReplyKeyboardRemove())
    	                  await state.finish()
    	                  
    	           
    	           await state.finish()
    	
        
@dp.message_handler(commands="profile")
async def profile(msg:types.Message):
    data=select(table="users", id=msg.from_user.id)
    user_channel_status_ru = await bot.get_chat_member(chat_id=CHANNEL_ID[0], user_id=msg.from_user.id)
    lang=select(table="language", id=msg.from_user.id)
    user_channel_status_en=await bot.get_chat_member(chat_id=CHANNEL_ID[1], user_id=msg.from_user.id)
    if user_channel_status_ru["status"] != "left" or user_channel_status_en["status"] != "left":
        if data is None:
            if lang[1]==1:
                await msg.answer(f"{translator.translate('зарегайся /start', src='ru', dest='en').text}")
            else:
                await msg.answer("зарегайся /start")
        else:
            if lang[1]==1:
                balance_info=select(table="pay", id=msg.from_user.id)
                user_info=select(table="users", id=msg.from_user.id)
                warning=select(table="rec", id=msg.from_user.id)
                saved_photo=select(table="media", id=msg.from_user.id)
                ooooo=f"баланс: {balance_info[2]}\nпревелегия: {balance_info[1]}\nпредупреждений: {warning[1]}\nсохраненых фото {len(saved_photo)}\nязык: EN"
                await msg.reply(f"{translator.translate(ooooo,src='ru', dest='en').text}")
            else:
                balance_info=select(table="pay", id=msg.from_user.id)
                user_info=select(table="users", id=msg.from_user.id)
                warning=select(table="rec", id=msg.from_user.id)
                saved_photo=select(table="media", id=msg.from_user.id)
                await msg.reply(f"баланс: {balance_info[2]}\nпревелегия: {balance_info[1]}\nпредупреждений: {warning[1]}\nсохраненых фото {len(saved_photo)}\nязык: RU")
                
