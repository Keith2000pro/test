import logging
from aiogram import Bot, Dispatcher, types, executor
import sqlite3 as sql, socket, vk_api, os, requests
from random import  choice, randint
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import  FSMContext
from bot.filters.filter import isAdminFilter
from aiogram.utils.exceptions import  MessageToEditNotFound, MessageToDeleteNotFound, RetryAfter, BadRequest, WrongFileIdentifier, MessageCantBeDeleted, NoStickerInRequest, MessageToDeleteNotFound
from aiogram.types import ParseMode, ContentType
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import  asyncio
import aiogram.utils.markdown as md

from PIL import Image, ImageFilter
from time import  sleep
from vk_api.longpoll import  VkLongPoll, VkEventType
from googletrans import  Translator

translator=Translator()
num=randint(0, 9282882819191)
subsc=translator.translate("подпишись на канал <a href='https://t.me/Hentai_V_O_X_EN'>Hentai</a>", src="ru", dest="en").text
subscRu=f"подпишись на канал <a href='https://t.me/Hentai_V_O_X_RU'>Hentai</a>"
#вка токен для странички
#1 это русский канал, 2 это английский
CHANNEL_ID=[-1001617608244, -1001608691731]
CHAT_ID=-1001773998933
TOKENVK="vk1.a.xoxN-Wi5XAIFF2PVmhuixDEnso04kKO8u4hxeUvdf3QqzGXYc-qXcZY7WJhjTwXLD2-mezMHTQAmYPRXbFXTIjvnM7P5g-9YulZcPVfoMH-lldZjUE0U5oxxG-7Y1ACi9paAXIE5JzHZ0qe7OTZKeIUDjwPOQC7rycCEFaiLCNKOTCQ0BgP2MVQq_bziTb6P"
#########
#телеграм


TOKEN="5410381397:AAH5Kz8T3JW8kNRxAsSCCdxFuS9rQuxjjpU"
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)
loop = asyncio.get_event_loop()
logging.basicConfig(level=logging.INFO)
dp = Dispatcher(bot=bot, storage=MemoryStorage(), loop=loop)

dp.filters_factory.bind(isAdminFilter)
kirill=5085467188
im=1338168183


class All_users:
    def __init__(self,db):
        self.conn=sql.connect(db)
        self.cursor=self.conn.cursor()
        
    def select_all_users(self, id, table):
        self.cursor.execute(f"SELECT * FROM {table} WHERE user_id=?", (id,))  
        data=self.cursor.fetchone()
        return data
    def  delete(self, table, ui):
        self.cursor.execute(f"DELETE FROM {table} WHERE user_id=?",(ui,))
        self.conn.commit()
            
allusees=All_users("bot/db/usersBot.db")
select=allusees.select_all_users
delete=allusees.delete        



hentais=[
'photo617809810_457240796', 'photo617809810_457240797', 'photo617809810_457240798', 'photo617809810_457240799', 'photo617809810_457240792', 'photo617809810_457240800', 'photo617809810_457240801', 'photo617809810_457240802', 'photo617809810_457240803', 'photo617809810_457240804', 'photo617809810_457240805', 'photo617809810_457240806', 'photo617809810_457240807', 'photo617809810_457240808', 'photo617809810_457240809', 'photo617809810_457240810', 'photo617809810_457240811', 'photo617809810_457240812', 'photo617809810_457240813', 'photo617809810_457240814', 'photo617809810_457240816',
'photo617809810_457240821']

png=['hentai.jpg', 'hentai1.jpg', 'hentai2.jpg', 'hentai3.jpg', 'hentai4.jpg', 'hentai5.jpg', 'hentai6.jpg', 'hentai7.jpg', 'hentai8.jpg', 'hentai9.jpg', 'hentai10.jpg', 'hentai11.jpg', 'hentai12.jpg', 'hentai13.jpg', 'hentai14.jpg', 'hentai15.jpg', 'hentai16.jpg', 'hentai17.jpg', 'hentai18.jpg', 'hentai19.jpg', 'hentai20.jpg', 'hentai21.jpg', 'hentai22.jpg', 'hentai23.jpg', 'hentai24.jpeg', 'hentai25.jpg', 'hentai26.jpg', 'hentai27.jpg', 'hentai28.jpg', 'hentai29.jpg', 'hentai30.jpg', 'hentai31.jpg', 'hentai32.jpg','hentai33.jpg', 'hentai34.jpg', 'hentai35.jpg', 'hentai36.jpg', 'hentai37.jpg', 'hentai38.jpg', 'hentai39.jpg']

@dp.message_handler(commands="regulations")          
async def regulationsa(msg:types.Message):
				lang=select(table="language", id=msg.from_user.id)
				ruless=f'1: Мат только для админов\n\n2: Запрещено кидать ссылки на другие каналы\n\n3: Запрещены оскорбление друг друга\n\n4: При получении 10 замечаний, вы будете изгнаны из группы'
				if lang[1]==1:
				    await msg.reply(translator.translate(ruless, src="ru", dest="en").text)    
				else:
				    await msg.reply(ruless)