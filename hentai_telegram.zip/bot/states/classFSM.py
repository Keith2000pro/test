from bot.moduls.settings import *
class add_balance(StatesGroup):
    balance=State()
    h=State()

class photo(StatesGroup):
    url=State()
    
                  
class stick_in_vk(StatesGroup):
    id=State()
    sticker=State()
    
class dos_attack(StatesGroup):
    url=State()    
    
class filet(StatesGroup):
    url=State()    
    
class hentai_pic(StatesGroup):
    recipient=State()

class status(StatesGroup):
    user_status=State()

class check_sub(StatesGroup):
                                                                ch=State()
class public_in_channel(StatesGroup):
                                                                photo=State()               
class search(StatesGroup):
                                                                _search=State()                                                 
class amount_photo(StatesGroup):
    k=State()                                                     
    
               
class filterimg(StatesGroup):
    photo_name=State()
    photo=State()                               
    
class get_forward_user(StatesGroup):
    user=State()                
    
class _set_photo(StatesGroup):
    photo=State()    

class Lang(StatesGroup):
    lang=State()        
    
    
class sncp(StatesGroup):
    chat_photo=State()
    _ChannelPhotoRu=State()
    _ChannelPhotoEn=State()

    
class VkPhotos(StatesGroup):
    photo=State()     
    
           
class titels(StatesGroup):
    titel=State()                      
    
class newTest(StatesGroup):
    url=State()          
    name=State()
   
    
class wtf(StatesGroup):
    text=State()
    
