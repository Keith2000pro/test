from aiogram import  types, Bot
from aiogram.dispatcher.filters import BoundFilter

class isAdminFilter(BoundFilter):
	key='is_admin'
	
	def __init__(self, is_admin):
		self.is_admin=is_admin
		
	async def check(self, msg:types.Message):
		member= await msg.bot.get_chat_member(msg.chat.id, msg.from_user.id)
		return member.is_chat_admin()	