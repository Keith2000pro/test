from bot.moduls.settings import *
from bot.states.classFSM import *
@dp.message_handler(commands="add", is_admin=True, commands_prefix="$")         
async def titel(msg:types.Message):
	try:
		await msg.delete()
		if not msg.reply_to_message:
			await msg.reply('должно быть ответом')
			return
		replyuser = msg.reply_to_message.from_user
		await bot.promote_chat_member(msg.chat.id,
		replyuser.id,
		can_delete_messages=True,   
		can_restrict_members=True,
		can_promote_members=True, 
		can_change_info=True,
		can_invite_users=True,  
		can_pin_messages=True) 
	except BadRequest:
		print('пользователь должен быть админом')
	
	
@dp.message_handler(commands="remove", is_admin=True, commands_prefix="$")         
async def remove_admin(msg:types.Message):
	await msg.delete()
	try:
		if not msg.reply_to_message:
			await msg.reply('должно быть ответом')
			return 
		replyuser = msg.reply_to_message.from_user
		await bot.promote_chat_member(msg.chat.id,
		replyuser.id,
		can_delete_messages=False,   
		can_restrict_members=False,
		can_promote_members=False, 
		can_change_info=False,
		can_invite_users=False,  
		can_pin_messages=False) 
	except BadRequest:
		print('shit')

	
@dp.message_handler(commands="rule", is_admin=True, commands_prefix="$")				
async def ruleuser(msg:types.Message):
	try:
		msgs=msg.text
		rules=msgs.split()
		await msg.delete()
		await bot.set_chat_administrator_custom_title(msg.chat.id, msg.reply_to_message.from_user.id, rules[1])
				
		
	except BadRequest:
		print('shit')
@dp.message_handler(commands="set_new_chat_photo")
async def set_new_chat_photo(msg:types.Message, state: FSMContext):
    if msg.chat.id !=msg.from_user.id:
        await msg.answer("в личку ")
    else:
        if msg.from_user.id == 1338168183 or msg.from_user.id ==5085467188:
            keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
            buttons = ["в чате", "в канале"]
            keyboard.add(*buttons)
            await msg.answer("где изменить фото?", reply_markup=keyboard)
  
  
@dp.message_handler(lambda msg: msg.text == "в канале")
async def in_channel(msg: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = ["Hentai EN", "Hentai RU"]
    keyboard.add(*buttons)
    await msg.answer("где изменить фото?", reply_markup=keyboard)
            
@dp.message_handler(lambda msg: msg.text == "Hentai EN")
async def in_channelEN(msg: types.Message, state: FSMContext):
            await msg.answer("отправьте фото документом", reply_markup=types.ReplyKeyboardRemove())
            await sncp._ChannelPhotoEn.set()
            
@dp.message_handler(lambda msg: msg.text == "Hentai RU")
async def in_channelRU(msg:types.Message, state: FSMContext):
        await msg.answer("отправьте фото документом", reply_markup=types.ReplyKeyboardRemove())    
        await sncp._ChannelPhotoRu.set()
        
    
@dp.message_handler(lambda msg: msg.text == "в чате")
async def chats(msg:types.Message, state: FSMContext):
    await msg.reply("отправьте фото документом",reply_markup=types.ReplyKeyboardRemove())
    await sncp.chat_photo.set()
    
@dp.message_handler(state=sncp.chat_photo, content_types="document")
async def chats_photo(msg:types.Message, state: FSMContext):
    async with state.proxy() as chattphoto:
            chattphoto["p"]=msg.document.file_id
            d=(await bot.download_file_by_id(chattphoto["p"]))
            await bot.set_chat_photo(chat_id=CHAT_ID, photo=d)
            
            
    
@dp.message_handler(state=sncp._ChannelPhotoRu, content_types="document")
async def n(msg:types.Message, state: FSMContext):
    async with state.proxy() as __Channel_photo_Ru:
            __Channel_photo_Ru["photo"]=msg.document.file_id
            download=(await bot.download_file_by_id(__Channel_photo_Ru["photo"]))
            await bot.set_chat_photo(CHANNEL_ID[0], download)
            await msg.answer("фото в hentai_RU изменено")
            await state.finish()    
            
            
            
            
@dp.message_handler(state=sncp._ChannelPhotoEn, content_types="document")       
async def setChat(msg:types.Message, state: FSMContext):
    async with state.proxy() as __Channel_photo_En:
        __Channel_photo_En["photo"]=msg.document.file_id
        download=(await bot.download_file_by_id(__Channel_photo_En["photo"]))
        await bot.set_chat_photo(CHANNEL_ID[1], download) 
        await msg.answer("фото в hentai_EN изменено")
        await state.finish()