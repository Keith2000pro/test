from bot.moduls.settings import *
from bot.states.classFSM import *
@dp.message_handler(content_types=ContentType.NEW_CHAT_MEMBERS)
async def new_member(msg: types.Message):
    await msg.delete()
    await msg.answer(f"{msg.from_user.full_name} присоеденился")
@dp.message_handler(content_types=ContentType.NEW_CHAT_PHOTO)
async def new_photo_chat(msg:types.Message):
    await msg.delete()
@dp.message_handler(content_types=ContentType.NEW_CHAT_TITLE)
async def new_titel(msg:types.Message):
    await msg.delete()        
@dp.message_handler(content_types=ContentType.LEFT_CHAT_MEMBER)    
async def left_member(msg:types.Message):
    await msg.delete()
    await msg.answer(f"{msg.from_user.full_name} покинул нашу Dungeon")
    
@dp.message_handler(commands="new_title")
async def new_title(msg:types.Message, state: FSMContext):
    if msg.chat.id != msg.from_user.id:
        await msg.reply("в лс")
    elif msg.from_user.id ==kirill or msg.from_user.id ==im:
        await msg.reply('введи новое название')
        await titels.titel.set()
        
    
@dp.message_handler(state=titels.titel)
async def set_titels(msg:types.Message, state: FSMContext):
        async with state.proxy() as titele:
            titele["text"]=msg.text
            await bot.set_chat_title(chat_id=CHAT_ID, title=titele["text"])
        await state.finish()
        await msg.reply("ok")
        
            
                
