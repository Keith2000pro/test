from bot.moduls.settings import *
from random import  choice
from bot.states.classFSM import *
async def lalalla(msg:types.Message):
    conn=sql.connect('bot/hentai_photos/pictures.db')
    cursor=conn.cursor()
    user = msg.from_user
    cursor.execute("SELECT * FROM photos")
    data = cursor.fetchall()
    return data
def p(text):
    print(text)    
    
def op(path, mode):
    open(path, mode)    


@dp.message_handler(commands="dir")
async def dir(msg:types.Message):
    try:
        os.chdir("bot/hentai_photos/pictures")
        i=-2
        g=open(choice(png), "rb")
        await msg.reply_photo(g)
    
              
                
    except:
        g=open(choice(png), "rb")
        await msg.reply_photo(g)
        