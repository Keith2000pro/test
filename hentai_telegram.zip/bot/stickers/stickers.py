from bot.moduls.settings import *

cursor.execute('INSERT OR IGNORE INTO rec VALUES(?,?)',(userdb.id, None))