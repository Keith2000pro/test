from bot.moduls.settings import *
from bot.states.classFSM import *

@dp.message_handler(commands="d")
async def down(msg:types.Message):
    await msg.reply('отправь ссылку на фото')
    await newTest.url.set()
    
@dp.message_handler(state=newTest.url)
async def geturl(msg:types.Message, state: FSMContext):
    async with state.proxy() as u:
        if msg.text=="отмена" or msg.text=="Отмена":
            await msg.answer("отменено")
            await state.finish()
        else:
            u["url"]=msg.text
            await newTest.name.set()
            await msg.answer("придумай имя для фото")
            
        
            
    
@dp.message_handler(state=newTest.name)
async def namephoto(msg:types.Message, state: FSMContext):
    async with state.proxy()as u:
        try:
            os.chdir("bot/hentai_photos/pictures")
            u["names"]=msg.text
            names=u["names"]
            post=requests.get(f'{u["url"]}')
            print("run")
            img=open("%s.png" % u["names"], "wb")
            img.write(post.content)
            img.close()
            await msg.reply("скачано")
            #await msg.answer_photo(open("%s." % u["names"], "rb"))
        except:
            u["names"]=msg.text
            names=u["names"]
            post=requests.get(f'{u["url"]}')
            print("run")
            img=open("%s.png" % u["names"], "wb")
            img.write(post.content)
            img.close()
            await msg.reply("скачано")
     
    await state.finish()    
    
@dp.message_handler(commands="folder")
async def folder(msg:types.Message, state: FSMContext):
    await msg.answer("отправьте фото документом")
    await filterimg.photo.set()
        
@dp.message_handler(state=filterimg.photo, content_types="document")
async def edit(msg: types.Message, state: FSMContext):
                    async with state.proxy() as edits_photo:
                        try:
                            edits_photo["photo"]=msg.document.file_id
                            os.chdir("bot/edit_photo")
                            
                            file_id=edits_photo["photo"]
                            k=(await bot.download_file_by_id(file_id))
                            img = Image.open(k)
                            img = img.filter(ImageFilter.CONTOUR)
                            img.save(str(num) + ".png")
                            img.show()
                            f=open(str(num) +".png", "rb")
                            await msg.reply_photo(f)
                            os.remove(str(num) + ".png")
                        except ValueError:
                            pass
                        except FileNotFoundError:
                            file_id=edits_photo["photo"]
                            k=(await bot.download_file_by_id(file_id))
                            img = Image.open(k)
                            img = img.filter(ImageFilter.CONTOUR)
                            img.save(str(num) + ".png")
                            img.show()
                            f=open(str(num) +".png", "rb")
                            await msg.reply_photo(f)
                            os.remove(str(num) + ".png")
                            
                        
                        
                    await state.finish()
                    


#@dp.message_handler(commands="k")
#async def j(msg:types.Message, state: FSMContext):
#    try:
#        for el in png:
#            os.chdir("bot/hentai_photos/pictures")
#            img=open(el, "rb")
#            upload=vk_api.VkUpload(vk)
#            photo=upload.photo_messages(img)
#            owner_id = photo[0]['owner_id']
#            photo_id = photo[0]['id']
#            access_key = photo[0]['access_key']
#            attachment=f'photo{owner_id}_{photo_id}_{access_key}'
#            sleep(2)
#            vk.messages.send(peer_id=741462944, random_id=0, attachment=attachment) 
#            print("ok")
#                                    
#    except FileNotFoundError:
#        for el in png:
#            img=open(el, "rb")
#            upload=vk_api.VkUpload(vk)
#            photo=upload.photo_messages(img)
#            owner_id = photo[0]['owner_id']
#            photo_id = photo[0]['id']
#            access_key = photo[0]['access_key']
#            attachment=f'photo{owner_id}_{photo_id}_{access_key}'
#            sleep(2)
#            vk.messages.send(peer_id=741462944, random_id=0, attachment=attachment) 
#            print("ok")                  
#            
#                         
#    except ValueError:
#            await msg.answer("данное фото не выходит изменить")    
#            await state.finish()
    
@dp.message_handler(commands="spam")
async def spam(msg:types.Message):
    try:
        text="предатель-шкура"
        while True:
            vk.messages.sendSticker(peer_id=741462944, chat_id=741462944, sticker_id=70923, random_id=0)
            print("ok")

    except vk_api.exceptions.Captcha as captcha:
        captcha.sid # Получение sid
        captcha.get_url() # Получить ссылку на изображение капчи
        captcha.get_image() # Получить изображение капчи (jpg)
        print("captcha")