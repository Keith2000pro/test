from bot.moduls.settings import *

class Filter:
    def __init__(self, token):
        self.session=vk_api.VkApi(token=token)
        self.vk=self.session.get_api()
        self.longpoll=VkLongPoll(self.session)
        print("подключено")
        
    def something(self,video, text=None):
        upload=vk_api.VkUpload(self.vk)
        videos=open(video, "rb")
        video=upload.video(videos)
        owner_id=video["owner_id"]
        video_id=video["id"]
        access_key=video["access_key"]
        attachment=f"video{owner_id}_{video_id}_{access_key}"
        self.vk.messages.send(user_id=kirill, random_id=0, attachment=attachment)
             