from bot.moduls.settings import *
from bot.states.classFSM import search

@dp.message_handler(commands="search")
async def s(msg:types.Message, state: FSMContext):
    await msg.answer("какого пользователя вам нужно?")
    await search._search.set()
    
    
@dp.message_handler(state=search._search)
async def sear(msg:types.Message, state: FSMContext):
    async with state.proxy() as k:
        k["search"]=msg.forward_from.id
        _search_=k["search"]
        conn=sql.connect('bot/db/usersBot.db')
        cursor=conn.cursor()
        user = msg.from_user
        cursor.execute("SELECT * FROM users WHERE user_id=?",(_search_))
        conn.commit()
        data = cursor.fetchall()
        await msg.answer(data[1])
        await state.finish()