from bot.moduls.all_lib import *
from bot.edit_photo.add import *
import asyncio
filter=Filter(token=TOKENVK)



if __name__=="__main__":
 executor.start_polling(dp)
 